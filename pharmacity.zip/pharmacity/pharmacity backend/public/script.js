document.addEventListener("DOMContentLoaded", () => {
  const citySelect = document.getElementById("citySelect");
  const pharmacyList = document.getElementById("pharmacyList");
  const pharmacyTitle = document.getElementById("pharmacyTitle");
  const adminBtn = document.getElementById("adminLoginBtn");
  const adminModal = document.getElementById("adminModal");
  const adminPanel = document.getElementById("adminPanel");
  const loginError = document.getElementById("loginError");
  const cityList = document.getElementById("cityList");

  let isAdmin = false;

  function loadCities() {
    fetch("/cities")
      .then((res) => res.json())
      .then((cities) => {
        citySelect.innerHTML = '<option value="">Şehir Seçiniz</option>';
        cityList.innerHTML = "";
        cities.forEach((city) => {
          const option = document.createElement("option");
          option.value = city.id;
          option.textContent = city.name;
          citySelect.appendChild(option);

          const li = document.createElement("li");
          li.innerHTML = `
            <div class="flex justify-between items-center border-b py-1">
              <span class="cursor-pointer text-blue-700 hover:underline" onclick="loadPharmaciesForCity(${city.id}, '${city.name}')">
                ${city.name}
              </span>
              <button onclick="deleteCity(${city.id})" class="text-red-600 hover:underline text-sm">Sil</button>
            </div>`;
          cityList.appendChild(li);
        });
      });
  }

  citySelect.addEventListener("change", () => {
    const cityId = citySelect.value;
    if (!cityId) return;
    fetchPharmacies(cityId, true);
  });

  function fetchPharmacies(cityId, scroll = false) {
    fetch(`/pharmacies/${cityId}`)
      .then((res) => res.json())
      .then((pharmacies) => {
        pharmacyList.innerHTML = "";
        pharmacyTitle.classList.remove("hidden");
        pharmacyTitle.textContent = "Seçilen Şehirdeki Eczaneler";

        const bgColors = [
          "bg-rose-50",
          "bg-orange-50",
          "bg-green-50",
          "bg-yellow-50",
          "bg-sky-50",
          "bg-purple-50",
        ];

        if (pharmacies.length === 0) {
          pharmacyList.innerHTML = "<p>Bu şehirde eczane bulunamadı.</p>";
        } else {
          pharmacies.forEach((pharmacy, index) => {
            const card = document.createElement("div");
            card.className = `rounded-lg shadow-md p-6 border ${
              bgColors[index % bgColors.length]
            }`;

            if (isAdmin) {
              card.innerHTML = `
                <input value="${pharmacy.name}" class="w-full font-bold text-lg mb-1 border-b border-gray-300" />
                <input value="${pharmacy.owner || ""}" placeholder="Sahibi" class="w-full mb-1 border-b border-gray-300" />
                <input value="${pharmacy.phone || ""}" placeholder="Telefon" class="w-full mb-1 border-b border-gray-300" />
                <input value="${pharmacy.address || ""}" placeholder="Adres" class="w-full mb-1 border-b border-gray-300" />
                <input value="${pharmacy.opening_hours || ""}" placeholder="Açılış Saati" class="w-full mb-1 border-b border-gray-300" />
                <input value="${pharmacy.closing_hours || ""}" placeholder="Kapanış Saati" class="w-full mb-1 border-b border-gray-300" />
                <select class="w-full mb-2 border-b border-gray-300">
                  <option value="1" ${pharmacy.is_nobetcı ? "selected" : ""}>Nöbetçi</option>
                  <option value="0" ${!pharmacy.is_nobetcı ? "selected" : ""}>Normal</option>
                </select>
                <div class="flex gap-2">
                  <button class="bg-green-600 text-white px-3 py-1 rounded" onclick="savePharmacy(this, ${pharmacy.id})">Kaydet</button>
                  <button class="bg-red-600 text-white px-3 py-1 rounded" onclick="deletePharmacy(${pharmacy.id}, ${pharmacy.city_id})">Sil</button>
                </div>
              `;
            } else {
              card.innerHTML = `
                <h3 class="text-lg font-bold text-[#b30000] mb-2">${pharmacy.name}</h3>
                <p><strong>Sahibi:</strong> ${pharmacy.owner || "Bilinmiyor"}</p>
                <p><strong>Telefon:</strong> ${pharmacy.phone || "Bilinmiyor"}</p>
                <p><strong>Adres:</strong> ${pharmacy.address || "Bilinmiyor"}</p>
                <p><strong>Saatler:</strong> ${pharmacy.opening_hours || "-"} - ${pharmacy.closing_hours || "-"}</p>
                <p><strong>Durum:</strong> ${pharmacy.is_nobetcı ? "Nöbetçi" : "Normal"}</p>
              `;
            }

            pharmacyList.appendChild(card);
          });
        }

        if (isAdmin) {
          const addForm = document.createElement("div");
          addForm.className =
            "rounded-lg shadow-md p-6 border border-dashed border-gray-400 bg-white";
          addForm.innerHTML = `
            <h3 class="text-lg font-bold text-[#b30000] mb-2">Yeni Eczane Ekle</h3>
            <input placeholder="Eczane Adı" class="w-full mb-1 border px-2 py-1" id="newPhName" />
            <input placeholder="Sahibi" class="w-full mb-1 border px-2 py-1" id="newPhOwner" />
            <input placeholder="Telefon" class="w-full mb-1 border px-2 py-1" id="newPhPhone" />
            <input placeholder="Adres" class="w-full mb-1 border px-2 py-1" id="newPhAddress" />
            <input placeholder="Açılış Saati" class="w-full mb-1 border px-2 py-1" id="newPhOpen" />
            <input placeholder="Kapanış Saati" class="w-full mb-1 border px-2 py-1" id="newPhClose" />
            <select class="w-full mb-2 border px-2 py-1" id="newPhNobet">
              <option value="0">Normal</option>
              <option value="1">Nöbetçi</option>
            </select>
            <button onclick="addPharmacy(${cityId})" class="bg-[#b30000] text-white px-4 py-2 rounded">Ekle</button>
          `;
          pharmacyList.appendChild(addForm);
        }

        if (scroll) scrollToPharmacyCards();
      });
  }

  function scrollToPharmacyCards() {
    const section = document.getElementById("pharmacyTitle");
    if (section) section.scrollIntoView({ behavior: "smooth" });
  }

  adminBtn.addEventListener("click", () => {
    adminModal.classList.remove("hidden");
    loginError.classList.add("hidden");
  });

  // ✅ Admin login backend üzerinden
  window.checkAdmin = function () {
    const username = document.getElementById("adminUsername").value;
    const password = document.getElementById("adminPassword").value;

    fetch("/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Login failed");
        return res.json();
      })
      .then(() => {
        isAdmin = true;
        adminModal.classList.add("hidden");
        adminPanel.classList.remove("hidden");
        loadCities();
      })
      .catch(() => {
        loginError.classList.remove("hidden");
      });
  };

  window.addCity = function () {
    const name = document.getElementById("newCityInput").value;
    if (!name) return;

    fetch("/add-city", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    })
      .then((res) => res.json())
      .then(() => {
        document.getElementById("newCityInput").value = "";
        loadCities();
      });
  };

  window.deleteCity = function (cityId) {
    if (!confirm("Şehir silinsin mi?")) return;

    fetch(`/delete-city/${cityId}`, { method: "DELETE" })
      .then((res) => res.json())
      .then(() => {
        loadCities();
        citySelect.value = "";
        pharmacyList.innerHTML = "";
        pharmacyTitle.classList.add("hidden");
      });
  };

  window.loadPharmaciesForCity = function (cityId, name) {
    citySelect.value = cityId;
    fetchPharmacies(cityId, true);
    pharmacyTitle.textContent = `${name} Şehrindeki Eczaneler`;
    pharmacyTitle.classList.remove("hidden");
  };

  window.deletePharmacy = function (pharmacyId, cityId) {
    if (!confirm("Eczane silinsin mi?")) return;

    fetch(`/delete-pharmacy/${pharmacyId}`, { method: "DELETE" })
      .then((res) => res.json())
      .then(() => fetchPharmacies(cityId));
  };

  window.savePharmacy = function (btn, id) {
    const inputs = btn.parentElement.parentElement.querySelectorAll("input, select");
    const [name, owner, phone, address, opening_hours, closing_hours, is_nobetcı] =
      Array.from(inputs).map((el) => el.value);

    fetch(`/update-pharmacy/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, owner, phone, address, opening_hours, closing_hours, is_nobetcı }),
    })
      .then((res) => res.json())
      .then(() => alert("Eczane güncellendi!"));
  };

  window.addPharmacy = function (cityId) {
    const name = document.getElementById("newPhName").value;
    const owner = document.getElementById("newPhOwner").value;
    const phone = document.getElementById("newPhPhone").value;
    const address = document.getElementById("newPhAddress").value;
    const opening_hours = document.getElementById("newPhOpen").value;
    const closing_hours = document.getElementById("newPhClose").value;
    const is_nobetcı = document.getElementById("newPhNobet").value;

    if (!name) {
      alert("Eczane adı zorunlu");
      return;
    }

    fetch("/add-pharmacy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        owner,
        phone,
        address,
        opening_hours,
        closing_hours,
        is_nobetcı,
        city_id: cityId,
      }),
    })
      .then((res) => res.json())
      .then(() => {
        alert("Eczane eklendi!");
        fetchPharmacies(cityId);
      });
  };

  loadCities();
});

// -------------------- CHAT WIDGET (ÇAKIŞMASIZ) --------------------
(function initChat() {
  const root = document.createElement("div");
  root.innerHTML = `
    <div id="pc-chat" class="fixed bottom-6 right-6 z-50 font-sans">
      <button id="pc-chat-toggle"
        class="bg-black text-white px-4 py-3 rounded-xl shadow-lg hover:opacity-90">
        💬 Asistan
      </button>

      <div id="pc-chat-panel"
        class="hidden bg-white w-[360px] h-[520px] rounded-2xl shadow-2xl mt-2 flex flex-col overflow-hidden border">
        <div class="bg-[#b30000] text-white p-4">
          <div class="font-extrabold text-lg leading-tight">PharmaCity Asistan</div>
          <div class="text-xs opacity-90">Sağlığınız her zaman önceliğimiz!</div>
        </div>

        <div id="pc-chat-messages" class="flex-1 overflow-y-auto p-4 text-sm bg-gray-50"></div>

        <div id="pc-chat-typing" class="hidden px-4 pb-2 text-xs text-gray-500">Asistan yazıyor…</div>

        <form id="pc-chat-form" class="p-3 border-t flex gap-2 bg-white">
          <textarea id="pc-chat-input"
            class="flex-1 border rounded-xl px-3 py-2 outline-none resize-none h-11"
            placeholder="Örn: İstanbul nöbetçi eczane / karnım ağrıyor"
            autocomplete="off"></textarea>
          <button id="pc-chat-send" class="bg-[#b30000] text-white px-4 rounded-xl">Gönder</button>
        </form>
      </div>
    </div>
  `;
  document.body.appendChild(root);

  const toggle = document.getElementById("pc-chat-toggle");
  const panel = document.getElementById("pc-chat-panel");
  const form = document.getElementById("pc-chat-form");
  const input = document.getElementById("pc-chat-input");
  const messages = document.getElementById("pc-chat-messages");
  const typing = document.getElementById("pc-chat-typing");

  function escapeHtml(str) {
    return (str || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function bubble(role, text) {
    const wrap = document.createElement("div");
    wrap.className = "mb-3";

    const isUser = role === "user";
    const align = isUser ? "text-right" : "text-left";
    const bg = isUser ? "bg-black text-white" : "bg-white text-gray-800";
    const name = isUser ? "Sen" : "Asistan";

    wrap.innerHTML = `
      <div class="${align}">
        <div class="inline-block max-w-[85%] px-4 py-3 rounded-2xl shadow-sm ${bg}">
          <div class="text-[11px] opacity-70 mb-2">${name}</div>
          <div style="white-space: pre-wrap; line-height: 1.35;">${escapeHtml(text)}</div>
        </div>
      </div>
    `;
    messages.appendChild(wrap);
    messages.scrollTop = messages.scrollHeight;
  }

  function ensureHello() {
    if (messages.childElementCount > 0) return;
    bubble(
      "assistant",
      "Merhaba 🙂\n\nİki şeyde iyiyim:\n• Şehir yazarsan nöbetçi eczaneleri listelerim\n• Belirti yazarsan (ör. karnım ağrıyor) güvenli şekilde yönlendiririm\n\nNasıl yardımcı olayım?"
    );
  }

  toggle.addEventListener("click", () => {
    panel.classList.toggle("hidden");
    if (!panel.classList.contains("hidden")) {
      ensureHello();
      setTimeout(() => input.focus(), 50);
    }
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = (input.value || "").trim();
    if (!text) return;

    bubble("user", text);
    input.value = "";

    typing.classList.remove("hidden");

    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });

      const data = await r.json();
      typing.classList.add("hidden");

      bubble("assistant", data.answer || "Bir şey ters gitti. Tekrar dener misin?");
    } catch {
      typing.classList.add("hidden");
      bubble("assistant", "Bağlantı sorunu var. Sunucu çalışıyor mu? (npm start)");
    }
  });
})();
