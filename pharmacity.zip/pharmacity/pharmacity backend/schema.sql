CREATE DATABASE IF NOT EXISTS pharmacity
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_turkish_ci;

USE pharmacity;

CREATE TABLE IF NOT EXISTS cities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS pharmacies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  owner VARCHAR(150),
  phone VARCHAR(50),
  address TEXT,
  opening_hours VARCHAR(20),
  closing_hours VARCHAR(20),
  is_nobetcı TINYINT(1) NOT NULL DEFAULT 0,
  city_id INT NOT NULL,
  INDEX(city_id),
  CONSTRAINT fk_city
    FOREIGN KEY (city_id) REFERENCES cities(id)
    ON DELETE CASCADE
);
