require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

// Optional drivers
const mysql = require("mysql");
const Database = require("better-sqlite3");

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// -------------------- Helpers --------------------
function normalizeTr(str) {
  return (str || "")
    .toString()
    .trim()
    .toLowerCase()
    .replaceAll("ı", "i")
    .replaceAll("İ", "i")
    .replaceAll("ğ", "g")
    .replaceAll("Ğ", "g")
    .replaceAll("ş", "s")
    .replaceAll("Ş", "s")
    .replaceAll("ç", "c")
    .replaceAll("Ç", "c")
    .replaceAll("ö", "o")
    .replaceAll("Ö", "o")
    .replaceAll("ü", "u")
    .replaceAll("Ü", "u");
}

function containsAny(hay, arr) {
  return arr.some((k) => hay.includes(k));
}

function isLikelyEmergency(text) {
  const t = normalizeTr(text);
  const redFlags = [
    "nefes darligi",
    "gogus agrisi",
    "bayil",
    "bilinc kaybi",
    "morarma",
    "kan kus",
    "felc",
    "yuzde kayma",
    "kol bacak gucsuz",
    "cok siddetli bas agrisi",
    "intihar",
    "zehirlen",
    "kahve telvesi kusma",
    "kanli diski",
    "siddetli karin agrisi",
    "sag alt karin agrisi"
  ];
  return redFlags.some((k) => t.includes(k));
}

function extractCityFromText(text, cities) {
  const n = normalizeTr(text);
  const sorted = [...cities].sort((a, b) => b.norm.length - a.norm.length);
  return sorted.find((c) => n.includes(c.norm)) || null;
}

function formatPharmacies(cityName, rows) {
  const list = rows
    .slice(0, 10)
    .map(
      (p, i) =>
        `${i + 1}) ${p.name}\n📍 ${p.address || "Adres yok"}\n📞 ${
          p.phone || "Telefon yok"
        }\n⏰ ${p.opening_hours || "?"} - ${p.closing_hours || "?"}`
    )
    .join("\n\n");

  return `🏥 ${cityName} nöbetçi eczaneler:\n\n${list}\n\nİstersen ilçe/mahalle yaz, daha iyi yönlendireyim.`;
}

// -------------------- Admin Login --------------------
app.post("/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  const adminUser = process.env.ADMIN_USER || "admin";
  const adminPass = process.env.ADMIN_PASSWORD || "admin123";

  if (username === adminUser && password === adminPass) {
    return res.json({ success: true });
  }

  return res.status(401).json({ success: false, message: "Hatalı kullanıcı adı veya şifre" });
});

// =====================================================
// DB LAYER (SQLite default, MySQL optional)
// =====================================================
const DB_DRIVER = (process.env.DB_DRIVER || "sqlite").toLowerCase();

let db = null; // sqlite instance
let mysqlConn = null; // mysql instance

// Uniform interface: query helpers
const DB = {
  init() {
    if (DB_DRIVER === "mysql") {
      mysqlConn = mysql.createConnection({
        host: process.env.DB_HOST || "localhost",
        user: process.env.DB_USER || "root",
        password: process.env.DB_PASSWORD || "",
        database: process.env.DB_NAME || "pharmacity",
        port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 3306
      });

      mysqlConn.connect((err) => {
        if (err) {
          console.error("❌ MySQL bağlantı hatası:", err.message);
          console.error("👉 İpucu: Kurulumsuz çalıştırmak için .env içinde DB_DRIVER=sqlite yap.");
          return;
        }
        console.log("✅ MySQL bağlantısı başarılı!");
      });

      return;
    }

    // SQLite default
    const sqlitePath = process.env.SQLITE_PATH || path.join(__dirname, "pharmacity.db");
    db = new Database(sqlitePath);
    db.pragma("journal_mode = WAL");

    // Schema
    db.exec(`
      CREATE TABLE IF NOT EXISTS cities (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
      );

      CREATE TABLE IF NOT EXISTS pharmacies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        owner TEXT,
        phone TEXT,
        address TEXT,
        opening_hours TEXT,
        closing_hours TEXT,
        is_nobetcı INTEGER NOT NULL DEFAULT 0,
        city_id INTEGER NOT NULL,
        FOREIGN KEY(city_id) REFERENCES cities(id) ON DELETE CASCADE
      );
    `);

    // Seed if empty
    const c = db.prepare("SELECT COUNT(*) AS c FROM cities").get().c;
    if (c === 0) {
      const insCity = db.prepare("INSERT INTO cities (name) VALUES (?)");
      const ist = insCity.run("İstanbul").lastInsertRowid;
      const ank = insCity.run("Ankara").lastInsertRowid;
      const izm = insCity.run("İzmir").lastInsertRowid;

      const insPh = db.prepare(`
        INSERT INTO pharmacies (name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, city_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insPh.run(
        "Örnek Nöbetçi Eczane",
        "Ecz. Demo",
        "0(212) 000 00 00",
        "Demo Mah. Demo Sok. No:1",
        "09:00",
        "23:59",
        1,
        ist
      );

      insPh.run(
        "Kızılay Demo Eczane",
        "Ecz. Demo",
        "0(312) 000 00 00",
        "Kızılay Demo Cad. No:5",
        "09:00",
        "19:00",
        1,
        ank
      );

      insPh.run(
        "Konak Demo Eczane",
        "Ecz. Demo",
        "0(232) 000 00 00",
        "Konak Demo Sok. No:7",
        "09:00",
        "19:00",
        0,
        izm
      );

      console.log("✅ SQLite demo verisi eklendi (kurulumsuz mod).");
    }

    console.log("✅ SQLite hazır:", sqlitePath);
  },

  // Cities
  getCities(cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query("SELECT * FROM cities ORDER BY id ASC", cb);
    }
    try {
      const rows = db.prepare("SELECT * FROM cities ORDER BY id ASC").all();
      cb(null, rows);
    } catch (e) {
      cb(e);
    }
  },

  addCity(name, cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query("INSERT INTO cities (name) VALUES (?)", [name], cb);
    }
    try {
      const r = db.prepare("INSERT INTO cities (name) VALUES (?)").run(name);
      cb(null, { insertId: r.lastInsertRowid });
    } catch (e) {
      cb(e);
    }
  },

  deleteCity(id, cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query("DELETE FROM cities WHERE id = ?", [id], cb);
    }
    try {
      db.prepare("DELETE FROM pharmacies WHERE city_id = ?").run(id);
      const r = db.prepare("DELETE FROM cities WHERE id = ?").run(id);
      cb(null, r);
    } catch (e) {
      cb(e);
    }
  },

  // Pharmacies
  getPharmaciesByCity(cityId, cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query("SELECT * FROM pharmacies WHERE city_id = ? ORDER BY id ASC", [cityId], cb);
    }
    try {
      const rows = db.prepare("SELECT * FROM pharmacies WHERE city_id = ? ORDER BY id ASC").all(cityId);
      cb(null, rows);
    } catch (e) {
      cb(e);
    }
  },

  addPharmacy(payload, cb) {
    const {
      name,
      owner,
      phone,
      address,
      opening_hours,
      closing_hours,
      is_nobetcı,
      city_id
    } = payload;

    if (DB_DRIVER === "mysql") {
      return mysqlConn.query(
        `INSERT INTO pharmacies (name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, city_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, city_id],
        cb
      );
    }

    try {
      const r = db.prepare(
        `INSERT INTO pharmacies (name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, city_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(name, owner || null, phone || null, address || null, opening_hours || null, closing_hours || null, Number(is_nobetcı) ? 1 : 0, city_id);

      cb(null, { insertId: r.lastInsertRowid });
    } catch (e) {
      cb(e);
    }
  },

  deletePharmacy(id, cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query("DELETE FROM pharmacies WHERE id = ?", [id], cb);
    }
    try {
      const r = db.prepare("DELETE FROM pharmacies WHERE id = ?").run(id);
      cb(null, r);
    } catch (e) {
      cb(e);
    }
  },

  updatePharmacy(id, payload, cb) {
    const {
      name,
      owner,
      phone,
      address,
      opening_hours,
      closing_hours,
      is_nobetcı
    } = payload;

    if (DB_DRIVER === "mysql") {
      return mysqlConn.query(
        `UPDATE pharmacies SET
          name = ?, owner = ?, phone = ?, address = ?,
          opening_hours = ?, closing_hours = ?, is_nobetcı = ?
         WHERE id = ?`,
        [name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, id],
        cb
      );
    }

    try {
      const r = db.prepare(
        `UPDATE pharmacies SET
          name = ?, owner = ?, phone = ?, address = ?,
          opening_hours = ?, closing_hours = ?, is_nobetcı = ?
         WHERE id = ?`
      ).run(name, owner || null, phone || null, address || null, opening_hours || null, closing_hours || null, Number(is_nobetcı) ? 1 : 0, id);

      cb(null, r);
    } catch (e) {
      cb(e);
    }
  },

  // For chatbot
  getNobetciByCityId(cityId, cb) {
    if (DB_DRIVER === "mysql") {
      return mysqlConn.query(
        "SELECT * FROM pharmacies WHERE city_id = ? AND is_nobetcı = 1",
        [cityId],
        cb
      );
    }
    try {
      const rows = db.prepare("SELECT * FROM pharmacies WHERE city_id = ? AND is_nobetcı = 1").all(cityId);
      cb(null, rows);
    } catch (e) {
      cb(e);
    }
  }
};

DB.init();

// -------------------- API: Cities --------------------
app.get("/cities", (req, res) => {
  DB.getCities((err, results) => {
    if (err) return res.status(500).json({ error: "Veritabanı hatası" });
    res.json(results);
  });
});

app.post("/add-city", (req, res) => {
  const { name } = req.body || {};
  if (!name) return res.status(400).json({ error: "Şehir adı zorunlu" });

  DB.addCity(name, (err, result) => {
    if (err) return res.status(500).json({ error: "Ekleme hatası" });
    res.json({ success: true, id: result.insertId });
  });
});

app.delete("/delete-city/:id", (req, res) => {
  const cityId = Number(req.params.id);
  if (!Number.isFinite(cityId)) return res.status(400).json({ error: "Geçersiz id" });

  // MySQL'de cascade yoksa önce eczaneler silinebilir; SQLite'da zaten siliniyor
  // Burada basit tutuyoruz:
  DB.deleteCity(cityId, (err) => {
    if (err) return res.status(500).json({ error: "Silme hatası" });
    res.json({ success: true });
  });
});

// -------------------- API: Pharmacies --------------------
app.get("/pharmacies/:city_id", (req, res) => {
  const cityId = Number(req.params.city_id);
  if (!Number.isFinite(cityId)) return res.status(400).json({ error: "Geçersiz city_id" });

  DB.getPharmaciesByCity(cityId, (err, results) => {
    if (err) return res.status(500).json({ error: "Veritabanı hatası" });
    res.json(results);
  });
});

app.post("/add-pharmacy", (req, res) => {
  const payload = req.body || {};
  if (!payload.name) return res.status(400).json({ error: "Eczane adı zorunlu" });

  DB.addPharmacy(payload, (err, result) => {
    if (err) return res.status(500).json({ error: "Ekleme hatası" });
    res.json({ success: true, id: result.insertId });
  });
});

app.delete("/delete-pharmacy/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Geçersiz id" });

  DB.deletePharmacy(id, (err) => {
    if (err) return res.status(500).json({ error: "Silme hatası" });
    res.json({ success: true });
  });
});

app.put("/update-pharmacy/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Geçersiz id" });

  DB.updatePharmacy(id, req.body || {}, (err) => {
    if (err) return res.status(500).json({ error: "Güncelleme hatası" });
    res.json({ success: true });
  });
});

// -------------------- CHATBOT (GELİŞMİŞ) --------------------
const HEALTH_RULES = [
  {
    keys: ["karin", "karnim", "mide", "midem", "karin agrisi", "mide agrisi"],
    answer:
      "🩺 Karın/mide ağrısı için birkaç şey soracağım:\n" +
      "1) Ne zamandır var?\n" +
      "2) Ağrı yeri neresi? (sağ alt, sol üst, göbek çevresi)\n" +
      "3) Ateş, kusma, ishal veya kan var mı?\n\n" +
      "⚠️ Şiddetli/artan ağrı, sağ alt karın ağrısı, bayılma, kanlı kusma-dışkı varsa acile başvur.\n" +
      "Not: Bu bilgiler tanı yerine geçmez."
  },
  {
    keys: ["ates", "atesim", "titreme"],
    answer:
      "🔥 Ateş için:\n" +
      "Kaç derece ölçtün ve kaç gündür sürüyor?\n" +
      "Bol sıvı + dinlenme önemli.\n\n" +
      "⚠️ 39+ ateş, nefes darlığı, göğüs ağrısı, bilinç bulanıklığı varsa acil değerlendirme gerekir.\n" +
      "Not: Bu bilgiler tanı yerine geçmez."
  },
  {
    keys: ["bogaz", "yutkun", "tonsil"],
    answer:
      "😷 Boğaz ağrısı için:\n" +
      "Öksürük, burun akıntısı, ateş var mı?\n" +
      "Sıcak içecekler ve dinlenme yardımcı olabilir.\n\n" +
      "⚠️ Şiddetli tek taraflı ağrı, yüksek ateş, nefes alma zorluğu varsa doktora başvur.\n" +
      "Not: Bu bilgiler tanı yerine geçmez."
  },
  {
    keys: ["bas agrisi", "migren", "basim agriyor"],
    answer:
      "🤕 Baş ağrısı için:\n" +
      "Yeni mi başladı, daha önce benzeri oldu mu?\n" +
      "Bulantı, ışık/ses hassasiyeti var mı?\n\n" +
      "⚠️ Ani en şiddetli baş ağrısı, konuşma-görme bozukluğu, güç kaybı varsa acil.\n" +
      "Not: Bu bilgiler tanı yerine geçmez."
  }
];

app.post("/api/chat", (req, res) => {
  const { message } = req.body || {};
  const text = (message || "").toString().trim();
  if (!text) return res.status(400).json({ error: "message zorunlu" });

  if (isLikelyEmergency(text)) {
    return res.json({
      answer:
        "⚠️ Bu anlattıkların acil olabilir.\n" +
        "Lütfen 112’yi ara veya en yakın acile başvur.\n\n" +
        "İstersen belirtileri yaz (ne zamandır, ateş/kusma/kan var mı), güvenli şekilde yönlendireyim."
    });
  }

  const n = normalizeTr(text);

  // Nöbetçi eczane intent
  if (containsAny(n, ["nobetci", "nobet", "acik eczane", "eczane"])) {
    DB.getCities((err, cities) => {
      if (err) return res.json({ answer: "Şehir listesine erişemedim. Tekrar dene." });

      const cityList = (cities || []).map((c) => ({ ...c, norm: normalizeTr(c.name) }));
      const hit = extractCityFromText(text, cityList);

      if (!hit) {
        return res.json({
          answer: "Hangi şehir için nöbetçi eczane arıyorsun?\nÖrn: “İstanbul nöbetçi eczane”"
        });
      }

      DB.getNobetciByCityId(hit.id, (err2, rows) => {
        if (err2) return res.json({ answer: "Eczane verisine erişemedim. Tekrar dene." });

        if (!rows || rows.length === 0) {
          return res.json({
            answer:
              `${hit.name} için sistemde nöbetçi eczane görünmüyor.\n` +
              "Admin panelden nöbetçi eczane işaretlendiğinden emin ol."
          });
        }

        return res.json({ answer: formatPharmacies(hit.name, rows) });
      });
    });

    return;
  }

  // Sağlık intent
  for (const rule of HEALTH_RULES) {
    const keysNorm = rule.keys.map(normalizeTr);
    if (keysNorm.some((k) => n.includes(k))) {
      return res.json({ answer: rule.answer });
    }
  }

  return res.json({
    answer:
      "Anladım 🙂\n\nŞöyle sorabilirsin:\n" +
      "• “İstanbul nöbetçi eczane”\n" +
      "• “karnım ağrıyor” / “ateşim var” / “boğazım ağrıyor”\n\n" +
      "Şu an ne hissediyorsun? (belirti + kaç gündür)"
  });
});

app.listen(port, () => {
  console.log(`🚀 PharmaCity çalışıyor: http://localhost:${port}`);
  console.log(`🧠 DB_DRIVER = ${DB_DRIVER} (default: sqlite)`);
});
