USE pharmacity;

INSERT INTO cities (name) VALUES
('İstanbul'),
('Ankara'),
('İzmir')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- İstanbul id
SET @IST := (SELECT id FROM cities WHERE name='İstanbul' LIMIT 1);
SET @ANK := (SELECT id FROM cities WHERE name='Ankara' LIMIT 1);
SET @IZM := (SELECT id FROM cities WHERE name='İzmir' LIMIT 1);

INSERT INTO pharmacies (name, owner, phone, address, opening_hours, closing_hours, is_nobetcı, city_id) VALUES
('Örnek Nöbetçi Eczane', 'Ecz. Demo', '0(212) 000 00 00', 'Demo Mah. Demo Sok. No:1', '09:00', '23:59', 1, @IST),
('Örnek Normal Eczane', 'Ecz. Demo', '0(212) 111 11 11', 'Deneme Cad. No:2', '09:00', '19:00', 0, @IST),
('Kızılay Demo Eczane', 'Ecz. Demo', '0(312) 000 00 00', 'Kızılay Demo Cad. No:5', '09:00', '19:00', 1, @ANK),
('Konak Demo Eczane', 'Ecz. Demo', '0(232) 000 00 00', 'Konak Demo Sk. No:7', '09:00', '19:00', 1, @IZM);
